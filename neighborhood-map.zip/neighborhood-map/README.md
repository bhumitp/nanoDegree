## Neighborhood Map project

### Instructions
Download all the necessary files and open the index.html file in the browser.

Click on the google map marker to load more information for that attraction.

Click the hamburger icon to expand the right side navigation bar and vice versa.

Click on the attraction from the nav bar to pull up the information for that attraction.

### Sources Used
[https://stackoverflow.com/questions/41033116/using-foursquare-api-in-google-map-using-javascript]
[https://developers.google.com/maps/documentation/javascript/adding-a-google-map]
[https://www.devbridge.com/articles/knockout-a-real-world-example/]
[https://stackoverflow.com/questions/25537026/implementation-of-knockout-dynamic-add-row]
[https://www.youtube.com/watch?v=Zxf1mnP5zcw]
[http://knockoutjs.com/documentation/introduction.html]
[https://v4-alpha.getbootstrap.com/components/navbar/?]
[https://cdnjs.com/libraries/tether]
[http://tether.io/]
[https://hpneo.github.io/gmaps/examples/json.html]
[https://stackoverflow.com/questions/42824881/i-am-trying-to-implement-foursquare-api-in-my-web-page-while-the-data-seems-to]
